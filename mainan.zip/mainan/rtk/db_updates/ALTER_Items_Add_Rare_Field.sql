ALTER TABLE `Items`
	ADD `ItmRare` int(10) NOT NULL
		AFTER `ItmUnequip`;