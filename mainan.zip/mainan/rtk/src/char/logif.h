#pragma once

int check_connect_login(int, int);
int logif_parse(int);
int logif_parse_login(int);