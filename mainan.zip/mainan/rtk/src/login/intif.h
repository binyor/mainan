#pragma once

int intif_auth(int);
int intif_parse(int);
