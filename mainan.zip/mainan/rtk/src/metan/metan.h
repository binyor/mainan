#ifndef _METAN_H_
extern Sql* sql_handle;
#endif

#include "../map/itemdb.h"

//int main();//int,char**);
int output_meta(char* filename, int num, unsigned int list[], int max);
