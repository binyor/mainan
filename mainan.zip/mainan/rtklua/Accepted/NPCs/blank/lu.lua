lu = {
	click = async(function(player, npc)
		Tools.configureDialog(player, npc)
		bank.show_main_menu(player, npc)
	end),
	}