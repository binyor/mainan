handwritten_note = {
	use = function(player)
		player:paperpopup(
			15,
			15,
			"We have received word of your success. You can handle a weapon, but can you handle the most difficult instrument of all - people?\n\nVisit the Oh Mudum crypt and pay respects to our fallen associates. The weather may be unpredictable, so be sure to bundle up and look in the mirror before you leave, as many people reverse their steps around graves.\n\nfnyivooz"
		)
	end
}
