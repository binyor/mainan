suspicious_note = {
	use = function(player)
		player:paperpopup(15, 15, "Gruff sits one to the left.\n\nmhfgsaqddyz")
	end
}
