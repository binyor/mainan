chaos_crown = {
	onEquip = function(player)
		player:warp(41, 30, 12)
	end
}
