enigmas_boots = {
	on_walk = function(player)
		local anim = 281

	if player.side == 0 then -- up
		player:sendAnimationXY(anim, player.x, player.y+1)
	elseif player.side == 1 then -- right
		player:sendAnimationXY(anim, player.x-1, player.y)
	elseif player.side == 2 then -- down
		player:sendAnimationXY(anim, player.x, player.y-1)
	elseif player.side == 3 then -- left
		player:sendAnimationXY(anim, player.x+1, player.y)
	end
		
	end,
}
