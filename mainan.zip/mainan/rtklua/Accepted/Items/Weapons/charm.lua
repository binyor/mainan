charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}

enchanted_charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}

il_san_charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}

ee_san_charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}

sam_san_charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}

sa_san_charm = {
	on_swing = function(player)
		local mob = getTargetFacing(player, BL_MOB)

		if mob ~= nil then
			if math.random(1, 100) <= 4 then
				endear.cast(player, mob)
			end
		end
	end
}
