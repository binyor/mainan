wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

malevolent_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

enchanted_wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

il_san_wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

ee_san_wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

sam_san_wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}

sa_san_wilderness_bow = {
	thrown = function(player, target)
		bow.thrown(player, target)
	end
}
