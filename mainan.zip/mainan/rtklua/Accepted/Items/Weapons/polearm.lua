polearm = {
	equip = function(player)
		player.extendHit = true
	end,

	re_equip = function(player)
		player.extendHit = true
	end,

	unequip = function(player)
		player.extendHit = false
	end,


}

heavy_polearm = {
	equip = function(player)
		player.extendHit = true
	end,

	re_equip = function(player)
		player.extendHit = true
	end,

	unequip = function(player)
		player.extendHit = false
	end,


}

military_polearm = {
	equip = function(player)
		player.extendHit = true
	end,

	re_equip = function(player)
		player.extendHit = true
	end,

	unequip = function(player)
		player.extendHit = false
	end,


}

