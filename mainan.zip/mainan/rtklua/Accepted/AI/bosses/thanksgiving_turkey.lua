thanksgiving_turkey = {
	on_spawn = function(mob)
		mob.speed = 20
		mob.registry["isturkey"] = 1
	end,
}