call_companion_red_wolf = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_green_squirrel = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_black_lobster = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_rabbit = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_fox = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_bear = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
call_companion_tiger = {
	on_healed = function(mob, healer)
		mob_ai_cotw.on_healed(mob, healer)
	end,
	on_attacked = function(mob, attacker)
		mob_ai_cotw.on_attacked(mob, attacker)
	end,
	move = function(mob, target)
		mob_ai_cotw.move(mob, target)
	end,
	attack = function(mob, target)
		mob_ai_cotw.attack(mob, target)
	end,
	after_death = function(mob)
		mob_ai_cotw.after_death(mob)
	end
}
